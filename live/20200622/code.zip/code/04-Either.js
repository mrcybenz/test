const Result = require('folktale/result');

function divide(x, y) {
  if (y === 0) {
    throw new Error('division by zero');
  } else {
    return x / y;
  }
}

// Result.Ok(1)  
// Result.Error(2)

console.log(Result.try(() => divide(4, 2)))
console.log(Result.try(() => divide(4, 0)))
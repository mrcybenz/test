class Functor {
  static of (value) {
    return new Functor(value)
  }
  constructor (value) {
    this._value = value
  }
  map (f) {
    return new Functor(f(this._value))
  }
  value (f) {
    return f(this._value)
  }
}

// 把美元转换成人民币
let money = '$20.8'

let toRMB = money => Functor.of(money)
  .map(m => m.replace('$', ''))
  .map(parseFloat)
  .map(m => m * 7)
  .value(m => '¥' + m)


console.log(toRMB(money))

const Maybe = require('folktale/maybe')

// 把美元转换成人民币
let money = '$20.8'

// let toRMB = money => Maybe.of(money)
//   .map(m => m.replace('$', ''))
//   .map(parseFloat)
//   .map(m => m * 7)
//   .map(m => '¥' + m)
//   .getOrElse()

// console.log(toRMB(money))

let toRMB = money => Maybe.fromNullable(money)
  .map(m => m.replace('$', ''))
  .map(parseFloat)
  .map(m => m * 7)
  .map(m => '¥' + m)
  .getOrElse('null')

console.log(toRMB(money))


const Functor = require('./functor')


let toRMB = money => Functor.of(money)
  .map(m => m.replace('$', ''))
  .map(parseFloat)
  .map(m => m * 7)
  .map(m => m.toFixed(2))
  .value(m => '¥' + m)


let money = '$20.30'

console.log(toRMB(money))
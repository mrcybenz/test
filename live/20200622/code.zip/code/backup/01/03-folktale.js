const Maybe = require('folktale/maybe')

let toRMB = x => Maybe.fromNullable(x)
// let toRMB = x => Maybe.of(x)
  .map(x => x.replace('$', ''))
  .map(parseFloat)
  .map(x => x * 7)
  .map(x => x.toFixed(2))
  .map(x => '¥' + x)
  .getOrElse('¥0')

let money = '$20.6'
console.log(toRMB(null))
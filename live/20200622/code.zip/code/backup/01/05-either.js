// folktale 中提供的 either
const Result = require('folktale/result');

function divide(x, y) {
  if (y === 0) {
    throw new Error('division by zero');
  } else {
    return x / y;
  }
}

console.log(Result.Ok('1'))
console.log(Result.Error('error'))

// console.log(Result.try(() => divide(4, 2)))
// console.log(Result.try(() => divide(4, 0)))

const safeDivide = (x, y) => Result.try(_ => divide(x, y))

console.log(safeDivide(5, 5).value)